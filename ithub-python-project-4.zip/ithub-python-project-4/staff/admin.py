from django.contrib import admin
from staff import models
from staff.models import Teacher, Manager


# Register your models here.
@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ['__str__', 'account']
    search_fields = ['last_name', 'first_name']

@admin.register(Manager)
class ManagerAdmin(admin.ModelAdmin):
    list_display = ['last_name', 'first_name', 'account']

# admin.site.register(models.Teacher, TeacherAdmin)