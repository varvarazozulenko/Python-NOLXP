from django.db import models
from sqlalchemy import false

from courses.models import Topic
from students.models import Student

class Assignment(models.Model): #сама ктшка
    weight = models.PositiveIntegerField(null=False, verbose_name='Количество баллов')
    topic = models.OneToOneField(Topic, on_delete=models.SET_NULL, null=True)
    updated_at = models.DateField(auto_now_add=True)


class Submission(models.Model): #ответ студента на ктшку
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE)
    answer = models.TextField(null=False)
    score = models.PositiveIntegerField(null=False, default=0)