from django.apps import AppConfig


class StudentsConfig(AppConfig):
    name = 'students'
    verbose_name = 'Студенты и учебные группы'
