from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy
from django.shortcuts import render, reverse
from courses import models

@login_required(login_url=reverse_lazy('login'))
def index(request):
    courses = models.Course.objects.filter(group=request.user.student.group)

    return render(
        request,
        'courses.html',
        { 'courses': courses }
    )

@login_required(login_url=reverse_lazy('login'))
def detail(request, course_id):
    course = models.Course.objects.get(pk=course_id)

    return render(
        request,
        'course.html',
        { 'course': course }
    )


@login_required(login_url=reverse_lazy('login'))
def topic(request, course_id, topic_id):
    topic = models.Topic.objects.get(pk=topic_id)

    return render(
        request,
        'topic.html',
        { 'topic': topic}
    )