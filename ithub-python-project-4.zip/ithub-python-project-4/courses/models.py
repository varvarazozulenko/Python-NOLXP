from django.db import models

from staff.models import Teacher
from students.models import Group
from staff.models import Teacher

class Discipline(models.Model):
    title = models.CharField(max_length=50, null=False, verbose_name="Название")
    duration = models.PositiveIntegerField(null=False, verbose_name='Длительность (ак.ч.)')
    curriculum = models.FileField(upload_to='curriculums/', null=True, blank=True, verbose_name="Учебный план")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Создано")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Обновлено")

    # def __str__(self):
    #     return f'{self.title} ({self.duration} ак.ч.)'

    class Meta:
        verbose_name = 'Дисциплина'
        verbose_name_plural = 'Дисциплины'
        ordering = ['-updated_at', '-created_at']

    def __str__(self):
        return self.title

class Course (models.Model):
    code = models.CharField(max_length=15, unique=True, null=False, verbose_name="Код курса")
    about = models.TextField(max_length=200, null=True, blank=True, verbose_name="Описание")
    course_start = models.DateField(null=True, blank=True, verbose_name="Дата начала")
    course_end = models.DateField(null=True, blank=True, verbose_name="Дата окончания")

    discipline = models.ForeignKey(Discipline, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Дисциплина")
    teacher = models.ForeignKey(Teacher, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Преподаватель")
    group = models.ForeignKey(Group, on_delete=models.CASCADE, null=False, related_name = 'students_group', blank=True, verbose_name="Группа")

    class Meta:
        verbose_name = 'Курс'
        verbose_name_plural = 'Курсы'
        ordering = ['discipline__title']
        indexes = [
            models.Index(fields=['code']),
        ]

    def __str__(self):
        return f"{self.code} - {self.discipline.title if self.discipline else 'Нет дисциплины'}"

class Topic (models.Model):
    title = models.CharField(max_length=50, null=False)
    content = models.TextField(null=False)
    updated_at = models.DateField(auto_now=True)
    duration = models.PositiveIntegerField(null=False, verbose_name='длительность')

    discipline = models.ForeignKey(Discipline, on_delete=models.SET_NULL, null=True)
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now=True)

class Meta:
    ordering = ['discipline__title', 'title']